import React from 'react'

function Logo({width = '100px'}) {
  return (
    <div>Logo</div>
  )
}

export default Logo